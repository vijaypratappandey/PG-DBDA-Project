# -*- coding: utf-8 -*-
"""
Created on Wed Jan 29 12:28:37 2020

@author: dbda
"""


import pandas as pd

reshaple = pd.read_csv(r'C:\Users\dbda\Desktop\Reshamle Data\resample.csv')

reshaple['Latitude'] = reshaple['Latitude'].map(str)
reshaple['Longitude'] = reshaple['Longitude'].map(str)
x = reshaple['Latitude'] +','+ reshaple['Longitude']

gg = pd.unique(x.values.ravel('K'))
m = pd.DataFrame({'a':gg})
m.to_csv(r'F:\sai\latlong.csv',index =False)
