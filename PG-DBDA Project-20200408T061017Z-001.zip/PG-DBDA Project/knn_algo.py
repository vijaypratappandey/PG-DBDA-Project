# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 02:20:40 2020

@author: dbda
"""

import pandas as pd
import numpy as np

reshaple = pd.read_csv(r'F:\sai\resample.csv')

reshaple.columns

X = reshaple.drop('Accident_Severity',axis=1)
y = reshaple['Accident_Severity']

from sklearn.neighbors import KNeighborsClassifier


parameters = {'n_neighbors': np.array([1,3,5,7,9])}

from sklearn.model_selection import StratifiedKFold
kfold = StratifiedKFold(n_splits=5, random_state=2020)

knn = KNeighborsClassifier()

from sklearn.model_selection import RandomizedSearchCV

cv = RandomizedSearchCV(knn, parameters,n_iter=50,random_state=2020,
                        cv=kfold,scoring='roc_auc',n_jobs=-1,verbose=2)

cv.fit(X,y)

print(cv.best_params_)

print(cv.best_score_)