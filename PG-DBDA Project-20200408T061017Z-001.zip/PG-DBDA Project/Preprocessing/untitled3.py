from flask import Flask, render_template, request
import pandas as pd
app = Flask(__name__)
res1 = dict()
def func(result):
   x = pd.read_csv(r"/home/file1.csv")
   p = x.loc[x['street']==x['src'],:]
   res1['1st_Road_Class'] =p['1st_Road_Class'].value_counts().index[0]
   res1['Did_Police_Officer_Attend_Scene_of_Accident'] =p['Did_Police_Officer_Attend_Scene_of_Accident'].value_counts().index[0]
   res1['Junction_Control'] =p['Junction_Control'].value_counts().index[0]
   res1['Light_Conditions'] = p['Light_Conditions'].value_counts().index[0]
   res1['Road_Surface_Conditions'] =p['Road_Surface_Conditions'].value_counts().index[0]
   res1['Junction_Detail'] =p['Junction_Detail'].value_counts().index[0]    
   return res1

@app.route('/')
def student():
   return render_template('student.html')

@app.route('/result',methods = ['POST', 'GET'])
def result():
   if request.method == 'POST':
      result = request.form
      result  = func(result)
      return render_template("result.html",result = result)

if __name__ == '__main__':
   app.run(debug = True)
