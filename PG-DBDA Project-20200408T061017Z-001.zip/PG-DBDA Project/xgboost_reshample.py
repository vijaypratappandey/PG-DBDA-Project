# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 02:20:40 2020

@author: dbda
"""

import pandas as pd

reshaple = pd.read_csv(r'F:\sai\resample.csv')

reshaple.columns

X = reshaple.drop('Accident_Severity',axis=1)
y = reshaple['Accident_Severity']

from xgboost import XGBClassifier

lr_range = [0.001, 0.01, 0.1, 0.2,0.25, 0.3]
n_est_range = [10,20,30,50,100]
md_range = [2,4,6,8,10]

parameters = dict(learning_rate=lr_range,
                  n_estimators=n_est_range,
                  max_depth=md_range)

from sklearn.model_selection import StratifiedKFold
kfold = StratifiedKFold(n_splits=5, random_state=2020)

from sklearn.model_selection import RandomizedSearchCV
clf = XGBClassifier(random_state=2020)
cv = RandomizedSearchCV(clf, parameters,n_iter=50,random_state=2020,
                        cv=kfold,scoring='roc_auc',n_jobs=-1,verbose=2)

cv.fit(X,y)

print(cv.best_params_)

print(cv.best_score_)