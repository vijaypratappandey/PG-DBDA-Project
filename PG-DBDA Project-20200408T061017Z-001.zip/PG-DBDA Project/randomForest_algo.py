# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 02:20:40 2020

@author: dbda
"""

import pandas as pd

reshaple = pd.read_csv(r'F:\sai\resample.csv')

reshaple.columns

X = reshaple.drop('Accident_Severity',axis=1)
y = reshaple['Accident_Severity']

from sklearn.tree import DecisionTreeClassifier

depth_range = [3,4,5,6,7,8,9]
minsplit_range = [5,10,20,25,30]
minleaf_range = [5,10,15]

parameters = dict(max_depth=depth_range,
                  min_samples_split=minsplit_range, 
                  min_samples_leaf=minleaf_range)

from sklearn.model_selection import StratifiedKFold
kfold = StratifiedKFold(n_splits=5, random_state=2020)

clf = DecisionTreeClassifier(random_state=2020)

from sklearn.model_selection import RandomizedSearchCV

cv = RandomizedSearchCV(clf, parameters,n_iter=50,random_state=2020,
                        cv=kfold,scoring='roc_auc',n_jobs=-1,verbose=2)

cv.fit(X,y)

print(cv.best_params_)

print(cv.best_score_)