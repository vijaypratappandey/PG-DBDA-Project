import pandas as pd
row_dropped = pd.read_csv(r'F:\sai\row_dropped.csv',engine='python')
from sklearn.impute import KNNImputer
imputer = KNNImputer(n_neighbors=1)
imputer1 = KNNImputer(n_neighbors=1)
imputer1.fit(pd.DataFrame(row_dropped.loc[:24999,['Driver_IMD_Decile','Latitude','Longitude']]))
x=pd.DataFrame()
for i in range(10):
    row_dropped.loc[1550000+i*25000,'Driver_IMD_Decile'] = 3.0 ###filling 8 most frequent
#row_dropped = row_dropped.replace({'LSOA_of_Accident_Location': {'Give way or uncontrolled': 1, 'Auto traffic signal':2,'Not at junction or within 20 metres':3,'Stop sign':2,'Authorised person':4}})
for i in range(62):
    imp_df = row_dropped.loc[i*25000:((i+1)*25000-1),['Driver_IMD_Decile','Latitude','Longitude']]
    imp_df = pd.DataFrame(imputer.fit_transform(imp_df),columns=['Driver_IMD_Decile','Latitude','Longitude'])
    x = pd.concat([x,imp_df],ignore_index=True)
    print(x.shape)
for i in range(62,71):
    imp_df = row_dropped.loc[i*25000:((i+1)*25000-1),['Driver_IMD_Decile','Latitude','Longitude']]
    imp_df = pd.DataFrame(imputer1.transform(imp_df),columns=['Driver_IMD_Decile','Latitude','Longitude'])
    x = pd.concat([x,imp_df],ignore_index=True)
    print(x.shape)
for i in range(71,81):
    imp_df = row_dropped.loc[i*25000:((i+1)*25000-1),['Driver_IMD_Decile','Latitude','Longitude']]
    imp_df = pd.DataFrame(imputer.fit_transform(imp_df),columns=['Driver_IMD_Decile','Latitude','Longitude'])
    x = pd.concat([x,imp_df],ignore_index=True)
    print(x.shape)
    
imp_df = row_dropped.loc[81*25000:,['Driver_IMD_Decile','Latitude','Longitude']]
imp_df = pd.DataFrame(imputer.fit_transform(imp_df),columns=['Driver_IMD_Decile','Latitude','Longitude'])
x = pd.concat([x,imp_df],ignore_index=True)
print(x.shape)
x.to_csv(r'C:\Users\dbda\Desktop\driver_decile.csv',index=False)

    