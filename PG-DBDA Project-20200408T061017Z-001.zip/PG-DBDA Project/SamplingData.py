# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 01:56:08 2020

@author: dbda
"""

import pandas as pd

acd = pd.read_csv(r'F:\sai\final_zero_nulls.csv',engine='python')

acd = acd.replace({'Accident_Severity': {'Slight':0, 'Serious':1,'Fatal':1}})

acd.info

X = acd.drop(['Accident_Severity','make','Date','Local_Authority_(District)','Police_Force'],axis=1)
X = pd.get_dummies(X)
y = acd['Accident_Severity']

from imblearn.over_sampling import RandomOverSampler

ros = RandomOverSampler(random_state=2020)

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, test_size=0.3,random_state=2020)

X_resampled, y_resampled = ros.fit_sample(X_train, y_train)

resampled = pd.concat([X_resampled,y_resampled],axis=1)

train = pd.concat([X_train,y_train],axis=1)

test = pd.concat([X_test,y_test],axis=1)

resampled.to_csv(r'F:\sai\resample.csv',index =False)
train.to_csv(r'F:\sai\train.csv',index =False)
test.to_csv(r'F:\sai\test.csv',index =False)



